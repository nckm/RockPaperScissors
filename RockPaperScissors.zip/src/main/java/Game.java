import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Game {
    private final Scanner userInput = new Scanner(System.in);
    private Player humanPlayer;
    private final Player robotPlayer = new Player("Robo-RPS");
    private boolean replay;
    private int humanWins, robotWins = 0;
    private final List<Player> playerList = new ArrayList<Player>();

    public static void main(String[] args) {
        Game game = new Game();
        game.playRobot();
    }

    // Display the main menu and allow the player to choose between a robot or human opponent
//    public void menu() {
//        System.out.println("Welcome to RockPaperScissors!");
//        System.out.println("Please choose from one of the following playable options:");
//        System.out.println("1) Against the computer");
//        System.out.println("2) Against another player");
//
//        int choice = userInput.nextInt();
//        if(choice == 1 || choice == 2) {
//            switch (choice) {
//                case 1:
//                    playComputer();
//                    break;
//                case 2:
//                    playHuman();
//                    break;
//            }
//        } else {
//            System.out.println("Incorrect input, please try again.");
//            menu();
//        }
//    }

    // Play against the robot
    public void playRobot() {
        // If the player is replaying or starting for the first time
        if(!replay) {
            System.out.println("Welcome to RockPaperScissors!");
            System.out.print("Please give your player a name: ");
            createNewPlayer();
            System.out.println("Hello " + humanPlayer.getName());
        } else if(replay) {
            System.out.println("\n\nWelcome back " + humanPlayer.getName() + "! Let's try again.");
            System.out.println(humanPlayer.getName() + " wins: " + humanWins);
            System.out.println("Robot wins: " + robotWins);
        }

        makeChoice();
        robotChoice();
        decideOutcome();

        // If the player/robot has won 3 rounds
        if(humanWins == 3) {
            System.out.println("You have won best of 3!");
            playAgain();
        } else if (robotWins == 3) {
            System.out.println("The robot has got best out of 3!");
            playAgain();
        } else {
            playRobot();
            replay = true;
        }
    }

    // Play as two human players
//    public void playHuman(){
//        System.out.print("Please enter player 1's name: ");
//        createNewPlayer();
//        System.out.println("\nPlease enter player 2's name: ");
//        createNewPlayer();
//
//        int i = 1;
//        for(Player p : playerList){
//            System.out.println("Player " + i + ": " + p.getName());
//            i++;
//        }
//    }

    // Create a new human player object
    public void createNewPlayer() {
        String name = userInput.nextLine();
        humanPlayer = new Player(name);
        humanPlayer.setName(name);
        playerList.add(humanPlayer);
    }

    // Let the player make a choice
    public void makeChoice() {
        System.out.print("\nPlease type in your choice of either 'rock', 'paper' or 'scissors': ");
        String choice = userInput.nextLine();

        switch (choice) {
            case "rock":
            case "scissors":
            case "paper":
                humanPlayer.setChoice(choice);
                System.out.println("You have selected " + choice);
                break;
            default:
                System.out.println("Your input was not recognised");
                makeChoice();
                break;
        }
    }

    // Randomise the robots choice
    public void robotChoice() {
        double rand = Math.random() * 3;

        if(rand <= 1){
            robotPlayer.setChoice("rock");
        } else if (rand > 1 && rand <= 2) {
            robotPlayer.setChoice("paper");
        } else if (rand > 2 && rand <= 3) {
            robotPlayer.setChoice("scissors");
        } else {
            System.out.println("Something went wrong!");
        }

        System.out.println("The robot has chosen " + robotPlayer.getChoice());
    }

    // Put the player and robots choice against each other to decide who wins
    public void decideOutcome() {
        String humanChoice = humanPlayer.getChoice();
        String robotChoice = robotPlayer.getChoice();

        if(humanChoice.equals(robotChoice)) {
            System.out.println("Draw");
            replay = true;
            playRobot();
        } else if (humanChoice.equals("rock")) {
            if(robotChoice.equals("scissors")) {
                System.out.println("Winner!");
                humanWins++;
            } else if (robotChoice.equals("paper")) {
                System.out.println("You lose!");
                robotWins++;
            }
        } else if (humanChoice.equals("paper")) {
            if(robotChoice.equals("rock")) {
                System.out.println("Winner!");
                humanWins++;
            } else if (robotChoice.equals("scissors")) {
                System.out.println("You lose!");
                robotWins++;
            }
        } else if (humanChoice.equals("scissors")) {
            if(robotChoice.equals("paper")) {
                System.out.println("Winner!");
                humanWins++;
            } else if (robotChoice.equals("rock")) {
                System.out.println("You lose!");
                robotWins++;
            }
        } else {
            System.out.println("Something went wrong with the choices!");
        }
    }

    // Ask if the player would like to play again
    public void playAgain() {
        System.out.println("\nWould you like to play again? y/n");
        String playAgain = userInput.nextLine();

        if(playAgain.equals("y") || playAgain.equals("Y")) {
            replay = true;
            playRobot();
        } else if (playAgain.equals("n") || playAgain.equals("N")) {
            System.exit(0);
        } else {
            System.out.println("Input not recognised. Please try again");
            playAgain();
        }
    }
}
